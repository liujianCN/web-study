import React from 'react'

export default class NotFoundPage extends React.Component {
    render(){
        return (
            <div>
                <p>NotFoundPage</p>
            </div>
        )
    }
}

