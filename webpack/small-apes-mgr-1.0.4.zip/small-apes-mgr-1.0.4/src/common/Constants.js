export default {
    NetWorkErrorDefaultMsg:"网络开小差了~"
}