import React from 'react'
import "./../index.less"
export default class BlogListPage extends React.Component {
    render(){
        return (
            <div>
                <div class="test test2">
                    <p>BlogListPage1</p>
                    <p>BlogListPage2</p>
                </div>
            </div>
        )
    }
}

